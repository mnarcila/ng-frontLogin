import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Orden } from '../ordenes/Orden';
import { OrdenRsType, OrdenService, StatusType, DetalleOrdenService, OrdenM, DetalleOrden } from '../_restOrdenes';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ordenes',
  templateUrl: './ordenes.component.html',
  styleUrls: ['./ordenes.component.scss']
})
export class OrdenesComponent implements OnInit {

  angForm: FormGroup;
  tablaOrdenes: boolean = false;
  listOrdenes: OrdenM[] = [];
  consultaTip: String;
  habilitaCrear: boolean;
  panelConsultar: boolean = false;
  panelCrear: boolean = false;
  panelActualizar:boolean = false;
  panelDetOrden:boolean = false;

  constructor(
    private ordenesApi: OrdenService,
    private auth: AuthService,
    private router: Router,
    private formBuilder: FormBuilder,
  ) { }



  ngOnInit() {
    console.log('entre al oninit');
    if (this.auth.isLoggedIn == false) {
      this.sendLogin();
    }
    this.createForm();
  }

  sendLogin(): void {
    this.router.navigate(["login"]);
  }

  createForm() {
    this.angForm = this.formBuilder.group({
      consultaId: ['', Validators.required],
      cliente: ['', Validators.required],
      producto: ['', Validators.required],
      paramConsulta: ['', Validators.required],
      tipoConsulta: ['', Validators.required],
      clienteID: ['', Validators.required],
      direccionID: ['', Validators.required],
      valTotal: ['', Validators.required],
      cantProductos: ['', Validators.required],
      fechaSol: ['', Validators.required],
      fechaAprob: ['', Validators.required],
      fechaCierre: ['', Validators.required]

    });
  }

  mostrarPanelConsulta(): void {
    if(!this.panelConsultar){
      this.panelConsultar = true;
      this.panelActualizar = false;
      this.panelCrear = false;
    }
  }

  mostrarPanelActualizar(): void {
    if(!this.panelActualizar){
      this.panelConsultar = false;
      this.panelActualizar = true;
      this.panelCrear = false;
      this.tablaOrdenes = false;
    }
  }

  mostrarPanelCrear(): void {
    if(!this.panelCrear){
      this.panelConsultar = false;
      this.panelActualizar = false;
      this.panelCrear = true;
      this.tablaOrdenes = false;
    }
  }

  procesarResponse(pValue: OrdenRsType) {

    console.log('procesarResponse ordenResponse');
    console.log(pValue);
    //this.productoRsType = pValue;
    //console.log(pValue.productos);
    this.listOrdenes.push(...pValue.datosBasicos.ordenes);
    //console.log("size: " + this.tablaProductos.length);
    //console.log("0: " + this.tablaProductos[0].nombre);
  }


  /**
   * Consulta la orden que tenga id el parametro enviado
   * @param ordenId id de la orden a consultar
   */
  colsultarOrdenXid(id: number): void {
    //this.listOrdenes = [];
    //if (this.angForm.controls.consultaId.value != '' && this.angForm.controls.consultaId.value != null) {
      this.tablaOrdenes = true;
      this.ordenesApi.conultarOrdenPorId('1', '1', id).subscribe(
        value => setTimeout(() => {
          const prd = value;
          this.procesarResponse(value);
        }, 200),
        error => console.error(JSON.stringify(error)),
        () => console.log('done')
      );
    //}
  }

  colsultarOrdenEstado(idEstado: number): void {
    this.listOrdenes = [];
    this.tablaOrdenes = true;
    this.ordenesApi.conultarOrdenesPorEstado('1', '1', idEstado).subscribe(
      value => setTimeout(() => {
        const prd = value;
        this.procesarResponse(value);
      }, 200),
      error => console.error(JSON.stringify(error)),
      () => console.log('done')
    );
  }

  colsultarOrdenXCliente(cliente: string ): void {
    //this.listOrdenes = [];
    //if (this.angForm.controls.cliente.value != '' && this.angForm.controls.cliente.value != null) {
      this.tablaOrdenes = true;
      this.ordenesApi.conultarOrdenPorCliente('1', '1', cliente).subscribe(
        value => setTimeout(() => {
          const prd = value;
          this.procesarResponse(value);
        }, 200),
        error => console.error(JSON.stringify(error)),
        () => console.log('done')
      );
    //}
  }

  colsultarOrdenXProducto(producto: number): void {
    this.listOrdenes = [];
    if (this.angForm.controls.producto.value != '' && this.angForm.controls.producto.value != null) {
      this.tablaOrdenes = true;
      this.ordenesApi.conultarOrdenesPorIdProducto('1', '1', producto).subscribe(
        value => setTimeout(() => {
          const prd = value;
          this.procesarResponse(value);
        }, 200),
        error => console.error(JSON.stringify(error)),
        () => console.log('done')
      );
    }
  }

  consultaGenerica(): void {
    this.listOrdenes = [];
    this.consultaTip =  this.angForm.controls.tipoConsulta.value;
    if (this.consultaTip != '' && this.consultaTip != null && this.consultaTip != '' && this.consultaTip != null) {
      //console.log('valor:' + this.angForm.controls.paramConsulta.value);
      switch (this.angForm.controls.tipoConsulta.value) {
        case '1': {
          console.log("entre 1: "+ this.angForm.controls.paramConsulta.value);
          this.colsultarOrdenEstado(this.angForm.controls.paramConsulta.value); 
          break;
        }
        case '2': {
          //console.log("entre 2");
          this.colsultarOrdenXCliente(this.angForm.controls.paramConsulta.value);
          break;
        }
        case '3': {
          //console.log("entre 3");
          break;
        }
        case '4': {
          //console.log("entre 4"); 
          this.colsultarOrdenXProducto(this.angForm.controls.paramConsulta.value);
          break;
        }
        case '5': {
          //console.log("entre 5"); 
          this.colsultarOrdenXid(this.angForm.controls.paramConsulta.value);
          break;
        }
        default: {
          console.log("entre default");
          break;
        }
      }
    }

  }

  crearOrdPanel(): void {
    if(this.habilitaCrear){
      this.habilitaCrear = false;
    }else {
      this.habilitaCrear = true;
    }
  }

  crearOrden(): void {
    let orden: OrdenM = {};
    orden.idCliente = this.angForm.controls.clienteID.value;
    orden.idDireccion = this.angForm.controls.direccionID.value;
    orden.valorTotal = this.angForm.controls.valTotal.value;
    orden.cantidadProductos = this.angForm.controls.cantProductos.value;
    orden.fechaSolicitud = this.angForm.controls.fechaSol.value;
    orden.fechaAprobacion = this.angForm.controls.fechaAprob.value;
    orden.fechaCierre = this.angForm.controls.fechaCierre.value;
    orden.estado = 1;
    console.log(orden);
    this.ordenesApi.registrarOrden('1', '1', orden).subscribe(
      value => setTimeout(() => {
        const prd = value;
        //this.consultaEspecifica(value.productos[0].idProducto);
        console.log(value);
      }, 200),
      error => console.error(JSON.stringify(error)),
      () => console.log('done')
    );
  }

  verDetalle(orden: OrdenM):void{
    console.log("entre al detalle");
    this.panelDetOrden = true;
  }
}
